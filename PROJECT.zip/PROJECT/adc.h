						#ifndef _ADC_H

#define _ADC_H


#include "types.h"


void Init_ADC(void);

f32 Read_ADC(u8 chNo);


#endif
