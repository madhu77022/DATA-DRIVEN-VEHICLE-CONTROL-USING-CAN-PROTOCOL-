#include<lpc21xx.h>
#include"can.h"
#include"lcd.h"
#include"DS18B20_tempsens.h"
#include"delay.h"
#include"interrupts.h"

int Gear;
int Window;
CANF Rx_Frame,Tx_Frame;

float arr[8]={12.5,25,37.5,50,62.5,75,87.5,100};
char str[20]="CAN MAJOR PROJECT  ";
char str1[20]="WELCOME    ";
char str2[20]="ID= V24HE5T6   ";

int main()
{
      int i;
      int distance;
      float temp;
      Init_CAN1();
	  InitLCD();
	  Init_Enable();
	  Tx_Frame.ID =3;
	  Tx_Frame.BFV.RTR = 0; 
	  Tx_Frame.BFV.DLC = 4;
	  IODIR0|=1<<9;
	  IOSET0 = 1<<9;
	  CmdLCD(0X80+5);
	  for(i=0;i<20;i++)
	  {
		    CharLCD(str1[i]);
			delay_ms(150);

	  }
	  CmdLCD(0XC0);
	  for(i=0;i<20;i++)
	  {
			CharLCD(str[i]);
			delay_ms(150);
	  }
	  delay_s(1);
	  CmdLCD(0X01);
	  for(i=0;i<20;i++)
	  {
		     CharLCD(str2[i]);
			 delay_ms(150);
	     
	  }
	  delay_s(1);
	  CmdLCD(0x01);	 
	  while(1)
	  {
	        
			temp = data_read();
			CmdLCD(0XC0);
			CharLCD('T');
			CharLCD('=');
			F32LCD(temp,1);
			CharLCD(0XDF);
			CharLCD('C');
	
	// FORWARD GEAR AND REVERSE GEAR OPERATIN USING INTERRUPTS
			if(Gear==1)
			{
				CmdLCD(0X80);
			    StrLCD("R:MODE");
			      
					   if(((C1GSR>>1)&1)==1) {
			 		   		CAN1_Rx(&Rx_Frame);	 

					          distance=Rx_Frame.Data1;
							  
					          CmdLCD(0X80+7);
					          StrLCD("D=");
					          U32LCD(distance);
							  if(distance<15)
							  {
							      IOPIN0^=1<<9;
							  }
							  else
							  {
							       IOSET0 =1<<9;
							  }
						}
						else {
							CmdLCD(0X80+7);
							StrLCD("         ");
						}   
			}
			else
			{
			        CmdLCD(0X80);  
			        StrLCD("F:MODE      ");
			}
	// WINDOW UP AND DOWN OPERATIN USING INTERRUPS
	 
	   switch(Window)
	   {
	          case 0: CmdLCD(0xC0+10);
			          StrLCD("W:");
					  StrLCD("OPEN  ");
					  break;
			  case 1: CmdLCD(0XC0+8);
					  StrLCD(" W:");
					  F32LCD(arr[1],1);
					  CharLCD('%');
					  break;
			  case 2:CmdLCD(0XC0+8);
					  StrLCD(" W:");
					  F32LCD(arr[2],1);
					  CharLCD('%'); 					
					  break;
			  case 3:CmdLCD(0XC0+8);
					  StrLCD(" W:");
					  F32LCD(arr[3],1);
					  CharLCD('%');
					  break;
			  case 4:CmdLCD(0XC0+8);
					  StrLCD(" W:");
					  F32LCD(arr[4],1);
					  CharLCD('%');
					  break;
			  case 5:CmdLCD(0xC0+8);
					  StrLCD(" W:");
					  F32LCD(arr[5],1);
					  CharLCD('%');
					  break;
			  case 6:CmdLCD(0XC0+8);
					  StrLCD(" W:");
					  F32LCD(arr[6],1);
					  CharLCD('%');
					  break;
			  case 7:CmdLCD(0XC0+8);
					  StrLCD("W:");
					  StrLCD("CLOSE  ");
					  break;
	   }	
	     
	 }

}
