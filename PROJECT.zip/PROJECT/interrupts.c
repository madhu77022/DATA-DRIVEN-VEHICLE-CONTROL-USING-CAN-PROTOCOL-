#include"lpc21xx.h"
#include"types.h"
#include"delay.h"
#include"can.h"


extern int Gear;
extern int Window;
extern CANF Tx_Frame;

#define	E0_PIN    16
#define E1_PIN	  14
#define	E2_PIN	  15
#define	E0_CH	  14
#define	E1_CH	  15
#define	E2_CH	  16

void Toggle_Gear(void)__irq
{
          Gear^=1; 

		  EXTINT = 1<<0;

		  VICVectAddr=0;
		  
}

void Window_up(void)__irq
{ 
         if(Window!=8)
		 {
		       Window++;

		 	Tx_Frame.Data1=Window;

		 	CAN1_Tx(Tx_Frame);
	     }

		 	EXTINT  =1<<1;

		 	VICVectAddr=0;

}
void Window_down(void)__irq
{
	if(Window!=0)
	   {

	        Window--;
	   
	        Tx_Frame.Data1=Window;

	        CAN1_Tx(Tx_Frame);
		}
	        EXTINT =1<<2;

	        VICVectAddr =0;

}

void Init_Enable(void)
{
	
        PINSEL0|=0XA0000000;
		PINSEL1 |=0X15400001;
		VICIntEnable=(1<<E0_CH)|(1<<E1_CH)|(1<<E2_CH);
		VICVectCntl0=(1<<5)|(E0_CH);
		VICVectAddr0=(u32)Toggle_Gear;
		VICVectCntl1=(1<<5)|(E1_CH);
		VICVectAddr1=(u32)Window_up;
		VICVectCntl2=(1<<5)|(E2_CH);
		VICVectAddr2=(u32)Window_down;
		EXTMODE = ((1<<0) | (1<<1) | (1<<2));
		//CONFIGURE  EINT0,EINT1&EINT2 AS FALLING EDGE TRIGGERD  (USE EXTPOLAR SFR)
}
