						  //pin_cfg.h

#ifndef _PIN_CFG_H

#define _PIN_CFG_H


#include "types.h"


void CfgPortPin(u32 portno,u32 pinno,u32 func);


#endif
