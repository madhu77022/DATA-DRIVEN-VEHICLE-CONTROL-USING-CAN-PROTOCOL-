#include<lpc21xx.h>
#include"lcd.h"
#include"lcd_defines.h"
#include"adc.h"
#include"adc_defines.h"
#include"delay.h"
#include"can.h"


f32 aR0;
f32 distance;
CANF txF;
f32 volt_dist(f32 eAR)
{
	 f32 v;
	 v=(eAR*(1024/5));
     distance = (6787/(v-3))-4;
	 return distance;	     
}
int main()
{
         Init_CAN1();
         Init_ADC();
	
		 txF.ID = 1;
		 txF.BFV.RTR =0;
		 txF.BFV.DLC =4;
		 while(1)
		 {     
		       aR0=Read_ADC(CH0);
			   distance = volt_dist(aR0);
		       if(distance>=6&&distance<=85)
			   {
			          
					  txF.Data1 =distance;		   					       
			   		CAN1_Tx(txF);
				}
			   delay_ms(100);    
              
		 }

}
