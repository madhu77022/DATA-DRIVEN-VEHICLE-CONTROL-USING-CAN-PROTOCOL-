#include"can.h"
#include<lpc21xx.h>

#define LED 0

CANF rxF;

int main()
{
	   IOSET0=0xFF<<LED;
       IODIR0|=255<<LED;
	   Init_CAN1();
	   while(1)
	   {
	          CAN1_Rx(&rxF);
			  if(rxF.ID == 3)
			  {
			      switch(rxF.Data1)
			      {
					        case 0:  IOCLR0 = 0XFF<<LED;
							         IOSET0 = 0XFF<<LED;
							         break;
							case 1:  IOCLR0 = 0XFF<<LED;
							         IOSET0 = 0XFE<<LED;
							         break;
							case 2:  IOCLR0 = 0XFF<<LED;
							         IOSET0 = 0XFC<<LED;
							         break;
							case 3:  IOCLR0 = 0XFF<<LED;
							         IOSET0 = 0XF8<<LED;
							         break;
							case 4:  IOCLR0 = 0XFF<<LED;
							         IOSET0 = 0XF0<<LED;
							         break;
							case 5:  IOCLR0 = 0XFF<<LED;
							         IOSET0 = 0XE0<<LED;
							         break;
							case 6:  IOCLR0 = 0XFF<<LED;
							         IOSET0 = 0XC0<<LED;
							         break;
							case 7:  IOCLR0 = 0XFF<<LED;
							         IOSET0 = 0X80<<LED;
						             break;
							case 8:  IOCLR0 = 0XFF<<LED;
							         IOSET0 = 0X00<<LED;
							         break;							 
			       }	
			  }      
	   }

}
